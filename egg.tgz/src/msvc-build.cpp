// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("msvc build\n", stdout);
  return lionss_run_workload("msvc-build");
}
