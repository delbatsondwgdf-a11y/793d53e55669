// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("smoke"); }
int main(){
  announce();
  return lionss_run_workload("smoke");
}
