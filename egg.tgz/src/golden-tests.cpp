// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("golden tests\n", stdout);
  return lionss_run_workload("golden-tests");
}
